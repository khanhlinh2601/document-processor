"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const upload_request_dto_1 = require("../shared/dtos/upload-request.dto");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const file_entity_1 = require("../domain/models/file.entity");
const s3_service_1 = require("../infrastructure/s3/s3.service");
const upload_file_service_1 = require("../application/upload-file.service");
const handler = async (event) => {
    try {
        const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const dto = (0, class_transformer_1.plainToInstance)(upload_request_dto_1.UploadRequestDto, body);
        const errors = await (0, class_validator_1.validate)(dto);
        if (errors.length) {
            return { statusCode: 400, body: JSON.stringify({ success: false, errors }) };
        }
        const files = dto.files.map(f => new file_entity_1.FileEntity(f.fileName, f.contentType, f.base64));
        const s3Service = new s3_service_1.S3Service();
        const uploadService = new upload_file_service_1.UploadFileService(s3Service);
        const uploadedFiles = await uploadService.uploadFiles(files);
        return {
            statusCode: 200,
            body: JSON.stringify({ success: true, uploadedFiles }),
        };
    }
    catch (err) {
        return {
            statusCode: 500,
            body: JSON.stringify({ success: false, message: err.message }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=upload.handler.js.map